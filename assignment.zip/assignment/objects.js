const favouriteBand= {
    Name: "Destiny's child",
    Nationality: "United States of America",
    Genre: "R&B",
    Members: 4,
    Formed: 1997,
    Split: 2006,
    Albums: [
        {
            name: "Survivor, The Writing's on The wall, Destiny Fulfilled, 8 Days of Christmas, Destiny's Child",
            released:  2001, 1999, 2004, 2001, 1998, 2006,
        }
        ]

    }

